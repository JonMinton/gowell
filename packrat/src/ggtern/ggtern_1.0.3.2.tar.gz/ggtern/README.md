ggtern
======

An extension to ggplot2, for the creation of ternary diagrams.

ggtern is a package that extends the functionality of ggpot2, giving the capability to plot ternary diagrams for (subset of) the ggplot2 proto geometries. 

For further examples and documentation, please proceed to the [ggtern website](http://www.ggtern.com).
